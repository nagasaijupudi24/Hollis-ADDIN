/* eslint-disable prettier/prettier */
// import "./excel";
// import "./outlook";
// import "./powerpoint";
// import "./word";

/* eslint-disable no-case-declarations */
/* eslint-disable no-undef */
/* eslint-disable prettier/prettier */
/* eslint-disable @typescript-eslint/no-unused-vars */
/*
 * Copyright (c) Microsoft Corporation. All rights reserved. Licensed under the MIT license.
 * See LICENSE in the project root for license information.
 */

/* global console, document, Office */

import { AccountManager } from "./authConfig";
import { v4 as uuidv4 } from 'uuid';
// import { makeGraphRequest } from "./msgraph-helper";
// import { writeFileNamesToOfficeDocument } from "./document";
const id = uuidv4();
const accountManager = new AccountManager();
let userName = "";
let bookableResourceObjectOFUser = {};
let selectedProjectIdTable;
let selectedProjectTaskIdTable;
let choiceOptions;
let selectedProjectIdNew;
let selectedProjectName;
let selectedProjectTaskIdNew;
let selectedProjectTaskName;
let pca = undefined;
let isPCAInitialized = false;
let token;
let domain = "https://hollis-projectops-uat-01.crm4.dynamics.com";
// let domain: any = "https://hollis-projectops-dev-01.api.crm4.dynamics.com";
// https://hollis-projectops-dev-01.api.crm4.dynamics.com

let options = [];
let dropdownListProject = document.getElementById("dropdownListForProject");
let dropdownListTask = document.getElementById("dropdownListForTask");
let searchInputProject = document.getElementById("searchInputForProject");
let searchInputTask = document.getElementById("searchInputForTask");
let projectError = document.getElementById("projectError");
let taskError = document.getElementById("taskError");
let duration = document.getElementById("duration");
let durationDropdown = document.getElementById("durationDropdown");
let durationError = document.getElementById("durationError");
let insertButton = document.getElementById("insertTimeEntry");
let insertError = document.getElementById("insertError");
let date = document.getElementById("date");
let dateError = document.getElementById("dateError");
let description = document.getElementById("description");
let descriptionTextarea = document.getElementById("descriptionTextarea");
let DescriptionError = document.getElementById("DescriptionError");
let currentAction = 0;
let mainButton = document.getElementById('mainButton');
let dropdownToggle = document.getElementById('dropdownToggle');
let dropdownMenu = document.getElementById('dropdownMenu');
const MAX_DURATION = 1440;
const MAX_DIGITS = 4; // 1440 has 4 digits

let projectnameArray = [];
let projectTaskArr = [];
let projectType = "Client";
let clearProjectandProjectTaskField = () => {
  //project and id set to empty 
  selectedProjectName = '';
  selectedProjectIdNew = '';

  //project Task and id set to empyt 

  selectedProjectTaskName = '';
  selectedProjectTaskIdNew = '';

  //input field clearing 
  searchInputTask.value = '';
  searchInputProject.value = '';
};
let client = document.getElementById("client");
let internal = document.getElementById("internal");

//Intial buttons positions

// client.disabled = true; // Disable the button after click
// internal.disabled = false;

client.addEventListener('click', async () => {
  // console.log("client")
  document.getElementById("dropdownListForProject").innerHTML = '';
  client.classList.add("active", "toggle-btn");
  internal.classList.remove("active");
  projectType = 'Client';
  await fetchProject(token);
  clearProjectandProjectTaskField();

  //disabling current button and enabling the other button 

  // client.disabled = true; // Disable the button after click
  // internal.disabled = false; // Enable the other button if needed
});
internal.addEventListener('click', async () => {
  // console.log("internal")
  document.getElementById("dropdownListForProject").innerHTML = '';
  internal.classList.add("active", "toggle-btn");
  client.classList.remove("active");
  projectType = 'Internal';
  await fetchProject(token);
  clearProjectandProjectTaskField();

  //disabling current button and enabling the other button 

  // internal.disabled = true; // Disable the button after click
  // client.disabled = false; // Enable the other button if needed
});
durationDropdown.addEventListener("change", function (event) {
  // console.log("User selected:", event.target.value);
});
async function getProjectById(projectId) {
  const url = `${domain}/api/data/v9.2/msdyn_projects(${projectId})?$select=msdyn_subject,msdyn_projectid`;
  try {
    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Accept": "application/json",
        "OData-MaxVersion": "4.0",
        "OData-Version": "4.0",
        "Content-Type": "application/json; charset=utf-8"
      }
    });
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Error fetching project: ${response.status} ${response.statusText}\n${errorText}`);
    }
    const data = await response.json();
    // console.log("✅ Project Name:", data.msdyn_subject);
    return data;
  } catch (error) {
    // console.error("❌ Fetch error:", error.message);
  }
}
const populateProjectTaskList = filteredKeys => {
  // Ensure that filteredKeys is an array
  if (Array.isArray(filteredKeys.value) && filteredKeys.value.length > 0) {
    // Clear existing options in selectTaskizeInstance

    // Add options dynamically
    filteredKeys.value.forEach(_project => {});

    // After adding all options, refresh the dropdown
  } else {
    console.error("filteredKeys is either not an array or it's empty.");
  }
};
function populateProjectTaskListNew(tasks) {
  dropdownListTask.innerHTML = ""; // Clear previous tasks
  if (tasks.length === 0) {
    let div = document.createElement("div");
    div.textContent = "There are no project tasks available for the selected project.";
    div.style.fontSize = "12px";
    div.style.color = "red";
    dropdownListTask.appendChild(div);
  }
  tasks.forEach(task => {
    let div = document.createElement("div");
    div.textContent = task.msdyn_subject;
    div.style.fontSize = "11px";
    div.style.color = "rgb(84, 84, 84)";
    div.style.borderBottom = "1px solid lightgrey";
    div.id = `${task.value}`;
    div.onclick = function () {
      searchInputTask.value = task.msdyn_subject;
      selectedProjectTaskName = task.msdyn_subject;
      dropdownListTask.style.display = "none";
      selectedProjectTaskIdNew = task.msdyn_projecttaskid;
    };
    dropdownListTask.appendChild(div);
  });
}
function filterOptionsProject() {
  let filter = searchInputProject.value.toLowerCase();
  let items = dropdownListProject.getElementsByTagName("div");
  for (let i = 0; i < items.length; i++) {
    let txtValue = items[i].textContent || items[i].innerText;
    items[i].style.display = txtValue.toLowerCase().includes(filter) ? "" : "none";
  }
}
function filterOptionsTask() {
  let filter = searchInputTask.value.toLowerCase();
  let items = dropdownListTask.getElementsByTagName("div");
  for (let i = 0; i < items.length; i++) {
    let txtValue = items[i].textContent || items[i].innerText;
    items[i].style.display = txtValue.toLowerCase().includes(filter) ? "" : "none";
  }
}
function showDropdownProject() {
  dropdownListProject.style.display = "block";
  populateDropdown(options);
}
const fetchMatchingProjects = async searchTerm => {
  // console.log(searchTerm)
  if (searchTerm.length < 3) {
    return; // Only fetch data when at least 3 characters are typed
  }

  // console.log("Fetching projects for search term:", searchTerm);

  try {
    const projectsResponse = await fetch(`${domain}/api/data/v9.2/msdyn_projects?$select=msdyn_subject,msdyn_projectid,ebecs_projectnumber20characters&$filter=ebecs_internal eq ${projectType === 'Internal'} and contains(msdyn_subject, '${searchTerm}') or contains(ebecs_projectnumber20characters,'${searchTerm}')`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}` // Ensure token is set properly
      }
    });
    if (!projectsResponse.ok) {
      const errorText = await projectsResponse.text();
      throw new Error(`Projects fetch failed: ${errorText}`);
    }
    const projectsData = await projectsResponse.json();
    // console.log("Filtered projects:", projectsData);
    let newOption = [];
    let projectnameArray = [];
    projectsData.value.forEach(each => {
      newOption.push({
        value: each.msdyn_projectid,
        text: each.msdyn_subject,
        projectNumber: each.ebecs_projectnumber20characters
      });
      projectnameArray.push({
        [each.msdyn_projectid]: each.msdyn_subject
      });
    });
    options = newOption;
    // console.log(newOption);
    populateDropdown(options);

    // console.log("Formatted Project List:", projectnameArray);

    // Populate projectInput datalist

    projectsData.value.forEach(_project => {});

    // Refresh dropdown
    // selectizeInstance.refreshOptions(false);

    const selectedProjectEntry = projectnameArray.find(obj => Object.values(obj)[0] === searchTerm);

    // console.log(selectedProjectEntry)

    if (!selectedProjectEntry) {
      console.warn("No matching project ID found for selected project.");
      return;
    }
    const selectedProjectId = Object.keys(selectedProjectEntry)[0];
    selectedProjectIdTable = selectedProjectId;

    // console.log("Selected Project ID:", selectedProjectId);

    fetchProjectTasks(selectedProjectId);
  } catch (error) {
    console.error("Error fetching projects:", error);
  }
};
searchInputProject.addEventListener("keyup", () => {
  dropdownListTask.innerHTML = '';
  filterOptionsProject();
});
searchInputProject.addEventListener("click", showDropdownProject);
searchInputProject.addEventListener("focus", () => {
  dropdownListTask.style.display = 'none';
});
searchInputProject.addEventListener("focus", () => {
  dropdownListProject.style.display = "block";
});
searchInputTask.addEventListener("focus", () => {
  dropdownListTask.style.display = "block";
});
document.addEventListener("click", e => {
  if (!dropdownListProject.contains(e.target) && !searchInputProject.contains(e.target)) {
    dropdownListProject.style.display = "none";
  }
  if (!dropdownListTask.contains(e.target) && !searchInputTask.contains(e.target)) {
    dropdownListTask.style.display = "none";
  }
});
searchInputTask.addEventListener("keyup", event => {
  if (event.key === 'Escape') {
    searchInputTask.blur(); // Removes focus from the input
    dropdownListTask.style.display = 'none';
  }
  filterOptionsTask();
});
searchInputTask.addEventListener("click", () => {
  dropdownListTask.style.display = "block";
}); // Show task dropdown when clicked

searchInputProject.addEventListener("blur", () => {
  projectError.textContent = "";
});
searchInputTask.addEventListener("blur", () => {
  taskError.textContent = "";
});
searchInputTask.addEventListener("focus", () => {
  dropdownListProject.style.display = 'none';
});
searchInputProject.addEventListener("keyup", event => {
  const searchTerm = event.target.value;
  fetchMatchingProjects(searchTerm);
  if (event.key === 'Escape') {
    searchInputProject.blur(); // Removes focus from the input
    dropdownListProject.style.display = 'none';
  }
  if (searchTerm === '') {
    fetchProject(token);
  }
});

// duration.addEventListener("keyup", (event: any) => {

//    if (event.key === 'Escape') {
//      duration.blur(); // Removes focus from the input

//     }

// });

description.addEventListener("keyup", event => {
  if (event.key === 'Escape') {
    description.blur(); // Removes focus from the input
  }
});
const fetchProjectTasks = async selectedProjectId => {
  // console.log("Project Task fetching")
  projectTaskArr = [];
  // console.log(selectedProjectId,"fetching project task")
  try {
    const responseProjectTask = await fetch(`${domain}/api/data/v9.0/msdyn_projecttasks?$select=msdyn_subject,_msdyn_project_value&$filter=_msdyn_project_value eq '${selectedProjectId}'`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
        "OData-MaxVersion": "4.0",
        "OData-Version": "4.0",
        Prefer: "odata.include-annotations=OData.Community.Display.V1.FormattedValue"
      }
    }).then(r => r.json()).then(result => {
      result.value.map(each => projectTaskArr.push(each.msdyn_subject));
      // console.log(result,"Project Task value")
    });
    let response = await fetch(`${domain}/api/data/v9.0/msdyn_projecttasks?$select=msdyn_subject,_msdyn_project_value&$filter=_msdyn_project_value eq '${selectedProjectId}'`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
        "OData-MaxVersion": "4.0",
        "OData-Version": "4.0",
        Prefer: "odata.include-annotations=OData.Community.Display.V1.FormattedValue"
      }
    });

    // console.log(response)
    if (response.ok) {
      response = await response.json();
      // console.log(response)

      populateProjectTaskListNew(response.value);
    } else {
      taskError.textContent = "Permission denied to access the Project Task Table.";
    }
    // .then((result=>{
    //   result.value.map(each=>projectTaskArr.push(each.msdyn_subject))
    //   console.log(result)

    // }));

    //  console.log(projectTaskArr)

    // // Populate projectTaskList

    populateProjectTaskList(response);
    populateProjectTaskListNew(response.value);
  } catch (error) {
    console.error("Failed to fetch project tasks:", error);
  }
};
function populateDropdown(options) {
  // console.log(options)
  dropdownListProject.innerHTML = "";
  options.forEach(option => {
    // console.log(option)
    const spanElement = document.createElement('span');
    spanElement.textContent = `${option.projectNumber === null ? "N/A" : option.projectNumber}`;

    // option.projectNumber===null && (spanElement.style.color = 'red')
    // Optional styling for the span
    spanElement.style.display = "block"; // Forces it to appear on a new line
    spanElement.style.fontSize = "10px"; // You can adjust this

    let div = document.createElement("div");
    div.id = `${option.value}`;
    div.style.fontSize = "11px";
    div.style.color = "rgb(84, 84, 84)";
    div.style.borderBottom = "1px solid lightgrey";

    // Add the option text as a text node (on the first line)

    const textNode = document.createTextNode(option.text);
    div.appendChild(textNode);

    // Add the span on the second line
    div.appendChild(spanElement);
    div.onclick = function () {
      getProjectById(option.value);
      searchInputProject.value = option.text;
      selectedProjectName = option.text;
      dropdownListProject.style.display = "none";
      // dropdownListTask.style.display = "none"
      // console.log(option.value)
      fetchProjectTasks(option.value); // Fetch tasks for selected project
      selectedProjectIdNew = option.value;
      searchInputTask.value = "";
    };
    dropdownListProject.appendChild(div);
  });
}
async function fetchProject(accessToken) {
  // console.log(userName)

  // console.log("project fetching called")
  // const projects= await fetch(
  //   `${domain}/api/data/v9.2/msdyn_projects`,
  //   {
  //     method: "GET",
  //     headers: {
  //       Authorization: `Bearer ${accessToken}`,
  //     },
  //   }
  // ).then(
  //   async (data)=>{
  //     console.log(await data.json())

  //   }
  // )

  try {
    // $filter=_msdyn_project_value eq '${selectedProjectId}'`
    const projectsResponse = await fetch(`${domain}/api/data/v9.2/msdyn_projects?$select=msdyn_subject,msdyn_projectid,ebecs_projectnumber20characters,ebecs_internal&$top=20&$filter=ebecs_internal eq ${projectType === 'Internal'} `, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${accessToken}`
      }
    });
    let newOption = [];
    if (projectsResponse.ok) {
      const projectsData = await projectsResponse.json();
      // console.log("Projects data retrieved successfully:", projectsData);

      projectsData.value.forEach(each => {
        newOption.push({
          value: each.msdyn_projectid,
          text: each.msdyn_subject,
          projectNumber: each.ebecs_projectnumber20characters
        });
        // 
        // projectnameArray.push({ [each.msdyn_projectid]: each.msdyn_subject });
      });
      options = newOption;
      // console.log(projectnameArray); // Output: [{ id1: "Project 1" }, { id2: "Project 2" }, ...]
      populateDropdown(options);
      // selectizeInstance.clearOptions();
      projectsData.value.forEach(project => {
        let optionObj = {
          value: project.msdyn_projectid,
          text: project.msdyn_subject
        };
        // console.log(optionObj)
      });

      // Refresh dropdown

      if (projectsData.value.length > 0) {
        // console.log(`Number of projects retrieved: ${projectsData.value.length}`);
      }
    } else {
      const errorText = await projectsResponse.text();
      throw new Error(`Projects fetch failed: ${errorText}`);
    }
  } catch (error) {
    console.error("Dynamics CRM API call failed:", error);
  }
}
async function fetchOptions(token) {
  // console.log("function called");
  try {
    const response = await fetch(`${domain}/api/data/v9.0/EntityDefinitions(LogicalName='msdyn_timeentry')/Attributes(LogicalName='hollis_projecttype')/Microsoft.Dynamics.CRM.PicklistAttributeMetadata?$select=LogicalName&$expand=OptionSet`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
        "OData-Version": "4.0",
        "OData-MaxVersion": "4.0"
      }
    });
    const data = await response.json();
    if (data && data.OptionSet && data.OptionSet.Options) {
      const optionsArray = []; // Initialize an array to hold the objects
      const options = data.OptionSet.Options;
      options.forEach(function (option) {
        const optionObject = {
          label: option.Label.UserLocalizedLabel.Label,
          value: option.Value
        };
        optionsArray.push(optionObject); // Append the object to the array
      });

      // console.log(optionsArray); // Output the array
      choiceOptions = optionsArray;
    } else {
      console.error("OptionSet or Options not found in response.");
    }
  } catch (error) {
    console.error("Error fetching or processing data:", error);
  }
}
let host;
const tokenRequestUserProfile = {
  scopes: ["User.Read"]
};
document.getElementById('insertTimeEntryOfficeApp').addEventListener('click', () => {
  // console.log('triggered in office')
  triggerFunction('save');
});
document.getElementById('mainButton').addEventListener('click', () => {
  // console.log('triggered in office')
  triggerFunction('saveAndClose');
});
Office.onReady(async info => {
  const closeBtn = document.getElementById("closePane");
  if (info.host === Office.HostType.Outlook) {
    document.getElementById('insertTimeEntryOfficeApp').style.display = 'none';
    closeBtn.addEventListener("click", () => {

      // console.log(Office.context.ui);
      // Office.context.ui.closeContainer()
    });
  } else {
    closeBtn.style.display = 'none';
    document.getElementById('splitButton').style.display = 'none';
    document.getElementById('mainButton').style.display = 'none';
    document.getElementById('dropdownToggle').style.display = 'none';
    document.getElementById('dropdownMenu').style.display = 'none';
    // document.getElementById('insertTimeEntryOfficeApp')!.style.display='block'
  }
  host = info.host;

  //   console.log(Office)
  // console.log(Office.context)
  // console.log(Office.context.document.getFilePropertiesAsync())
  switch (info.host) {
    case Office.HostType.Excel:
    case Office.HostType.PowerPoint:
    case Office.HostType.Word:
    case Office.HostType.Outlook:
      // await getFileNames()
      // await getUserData()

      // console.log("entered in host:",info.host)
      await accountManager.initialize();

      //    const userAccount = await accountManager.ssoGetUserIdentity(["user.read"]);
      //   const idTokenClaims = userAccount.idTokenClaims as { name?: string; preferred_username?: string };
      //     console.log(userAccount)
      //   console.log(userAccount.accessToken);

      //    const response = await fetch(`https://graph.microsoft.com/v1.0/me`, {
      //   headers: { Authorization: userAccount.accessToken },
      // });

      // if (response.ok) {
      //   // Get the user name from response JSON.
      //   const data = await response.json();
      //   const name = data.displayName;

      //   if (name) {
      //     console.log("You are now signed in as " + name + ".");
      //   }
      // } else {
      //   const errorText = await response.text();
      //   console.log("Microsoft Graph call failed - error text: " + errorText);
      // }

      const accessToken2 = await accountManager.ssoGetToken([`${domain}/user_impersonation`]); //Hollis scope
      // console.log("Access token2: ", accessToken2);
      const [tokenFromSSO, username] = accessToken2;
      // console.log(username)
      userName = username;
      token = tokenFromSSO;
      await fetchOptions(tokenFromSSO);
      await fetchProject(tokenFromSSO);

      // $select=msdyn_subject,msdyn_projectid,ebecs_projectnumber20characters&$filter=contains(msdyn_subject, '${searchTerm}') or contains(ebecs_projectnumber20characters,'${searchTerm}')

      // _msdyn_organizationalunit_value realted api

      await fetch(`${domain}/api/data/v9.2/bookableresources?$select=name,_msdyn_organizationalunit_value&$filter=contains(name, '${userName}')`, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`
        }
      }).then(async data => {
        // console.log(await data.json())
        bookableResourceObjectOFUser = await data.json();
        bookableResourceObjectOFUser = bookableResourceObjectOFUser.value[0];
        console.log(bookableResourceObjectOFUser, "bookable Resource Object OF User");
        // if(bookableResourceObjectOFUser === undefined){
        //   insertError.textContent = "User not identified in the bookable resources. Cannot insert the time entry."

        // }
      });
      let item;
      if (info.host === Office.HostType.Outlook) {
        item = Office.context.mailbox.item;
      }
      if (item && item.itemType === Office.MailboxEnums.ItemType.Appointment) {
        setEventDetails();
      }
      break;
  }

  // Function to fetch event details and assign them to the input fields
  function setEventDetails() {
    const item = Office.context.mailbox.item;

    // === Description/Subject ===
    const descriptionField = document.querySelector(".description-field");
    if (descriptionField) {
      if (typeof item.subject === "string") {
        // Read mode
        descriptionField.value = item.subject;
        // descriptionField.disabled = true;
      } else if (typeof item.subject?.getAsync === "function") {
        // Edit mode
        item.subject.getAsync(result => {
          if (result.status === Office.AsyncResultStatus.Succeeded) {
            descriptionField.value = result.value;
            // descriptionField.disabled = true;
          } else {
            console.error("Failed to fetch subject:", result.error);
          }
        });
      }
    }

    // === Start Date ===
    const eventDateField = document.querySelector(".event-date");
    if (eventDateField) {
      if (item.start instanceof Date) {
        // Read mode
        const formattedStart = item.start.toISOString().split("T")[0];
        eventDateField.value = formattedStart;
        // eventDateField.disabled = true;
      } else if (typeof item.start?.getAsync === "function") {
        // Edit mode
        item.start.getAsync(result => {
          if (result.status === Office.AsyncResultStatus.Succeeded && result.value) {
            const startTime = new Date(result.value);
            const formattedStart = startTime.toISOString().split("T")[0];
            eventDateField.value = formattedStart;
            // eventDateField.disabled = true;
          } else {
            console.error("Failed to fetch start date:", result.error);
          }
        });
      }
    }

    // === Duration ===
    const eventDurationField = document.querySelector(".event-duration");
    const getStartEndTime = callback => {
      let startTime = null;
      let endTime = null;
      const tryCalculate = () => {
        if (startTime && endTime && callback) {
          const duration = (endTime - startTime) / (1000 * 60); // minutes
          callback(duration);
        }
      };
      const handleAsync = () => {
        item.start.getAsync(startResult => {
          if (startResult.status === Office.AsyncResultStatus.Succeeded) {
            startTime = new Date(startResult.value);
            item.end.getAsync(endResult => {
              if (endResult.status === Office.AsyncResultStatus.Succeeded) {
                endTime = new Date(endResult.value);
                tryCalculate();
              } else {
                console.error("Failed to fetch end time:", endResult.error);
              }
            });
          } else {
            console.error("Failed to fetch start time:", startResult.error);
          }
        });
      };
      if (item.start instanceof Date && item.end instanceof Date) {
        // Read mode
        startTime = item.start;
        endTime = item.end;
        tryCalculate();
      } else if (typeof item.start?.getAsync === "function" && typeof item.end?.getAsync === "function") {
        // Edit mode
        handleAsync();
      } else {
        console.error("Start or End time not available.");
      }
    };
    if (eventDurationField) {
      getStartEndTime(duration => {
        // eventDurationField.value = duration;
        // eventDurationField.disabled = true;
      });
    }
  }
});
function mapProjectType(choiceOptions, projectType) {
  // Convert projectType to lowercase
  let projectTypeValue = projectType.toLowerCase();

  // Find the matching object in choiceOptions
  const matchedOption = choiceOptions.find(option => option.label.toLowerCase() === projectTypeValue);

  // Return the corresponding value or null if not found
  // console.log(matchedOption)
  return matchedOption ? matchedOption.value : null;
}
function getFieldValues() {
  // let fieldArray=[
  //   {date:{value:date.value,error:dateError}},
  //   {project:{value:searchInputProject.value,error:projectError}},
  //   {projectTask:{value:searchInputTask.value,error:taskError}},
  //   {duration:{value:duration.value,error:durationError}},
  //   {description:{value:description.value,error:DescriptionError}}
  // ]

  let fieldArray = [{
    value: date.value,
    error: dateError,
    errorMessage: "Please Select Date"
  }, {
    value: searchInputProject.value,
    error: projectError,
    errorMessage: "Please select project"
  }, {
    value: searchInputTask.value,
    error: taskError,
    errorMessage: "Please select project Task"
  },
  //  {value:duration.value,error:durationError,errorMessage:"Please Fill the duration"},
  {
    value: durationDropdown.value,
    error: durationError,
    errorMessage: "Please Select the duration"
  }
  // {value:description.value,error:DescriptionError,errorMessage:"Please Fill Description"}
  ];
  return fieldArray;
}
const triggerFunction = type => {
  let error = validateField();
  if (error.length > 0) {
    // console.log("Termination of submission")
    return;
  }

  // insertButton.style.pointerEvents = "none";
  // insertButton.style.opacity = "0.5";
  insertError.textContent = "Please wait while data is submitting .....";
  insertError.style.color = "black";

  // console.log("reach after validation")

  createFieldValues(type);
};
const actions = {
  0: () => {
    triggerFunction("saveAndClose");
  },
  1: () => {
    triggerFunction("save");
  },
  2: () => {
    triggerFunction("saveAndClose");
  }
};
dropdownToggle?.addEventListener('click', e => {
  e.stopPropagation(); // Prevent triggering the document click
  const isVisible = dropdownMenu.style.display === 'block';
  dropdownMenu.style.display = isVisible ? 'none' : 'block';
  if (!isVisible) {
    dropdownMenu.style.marginBottom = '16px'; // Add space at bottom

    setTimeout(() => {
      dropdownMenu.scrollIntoView({
        behavior: 'smooth',
        block: 'end'
      });
    }, 50);
  }
});

// Handle dropdown option click
dropdownMenu?.addEventListener('click', e => {
  if (e.target.tagName === 'BUTTON') {
    const selected = e.target.getAttribute('data-action');
    dropdownMenu.style.display = 'none';
    if (selected && actions[selected]) {
      actions[selected](); // Immediately trigger the associated action
    }
  }
});

// Hide dropdown when clicking outside
document.addEventListener('click', e => {
  if (!document.getElementById('splitButton').contains(e.target)) {
    dropdownMenu.style.display = 'none';
  }
});
function validateField() {
  // ✅ Get the current value when the event fires
  let fieldArray = getFieldValues();
  // const latestSearchValue = searchInputProject.value;
  // console.log("Latest search input value:", latestSearchValue);
  // console.log(fieldArray,"field Validation")
  let error = [];
  for (let each of fieldArray) {
    // console.log(each.value)
    if (each.value === "") {
      // console.log(each.error,"Error")
      each.error.textContent = each.errorMessage;
      error.push(each.errorMessage);
    }
  }
  // console.log(error)
  // console.log(error.length)

  return error;
}
;

// Insert Time Entry Button
// document.getElementById("insertTimeEntry")!.addEventListener("click", 
//   () => {

//   let error = validateField()

//   if (error.length > 0){
//     // console.log("Termination of submission")
//     return
//   }

//   insertButton.style.pointerEvents = "none";
//   insertButton.style.opacity = "0.5";
//   insertError.textContent = "Please wait while data is submitting .....";
//   insertError.style.color = "black"

//   // console.log("reach after validation")

//   createFieldValues();
// }
// );

// duration.addEventListener("focus",()=>{
//   durationError.textContent = ""
// })

durationDropdown.addEventListener("focus", () => {
  durationError.textContent = "";
});
date.addEventListener("focus", () => {
  dateError.textContent = "";
});
description.addEventListener("focus", () => {
  DescriptionError.textContent = "";
});
async function createFieldValues(type) {
  let dateElement = document.querySelector(".event-date");

  // console.log("Selected Project Type:", projectType);

  let durationElement = document.querySelector(".event-duration");
  let descriptionElement = document.querySelector(".description-field");
  let dateValue = dateElement ? dateElement.value : "";
  let durationValue = durationElement ? durationElement.value : "";
  let descriptionValue = descriptionElement ? descriptionElement.value : "";

  // Log extracted values
  // console.log("Extracted Values:");
  // console.log("Date Value:", dateValue);
  // console.log("Project Type Value:", projectTypeValue);
  // console.log("Project Value:", selectedProjectIdTable);
  // console.log("Project Task Value:", selectedProjectTaskIdTable);
  // console.log("Duration Value:", durationValue);
  // console.log("Description Value:", descriptionValue);

  // Convert date to ISO 8601 format
  let formattedDate = dateValue ? new Date(dateValue).toISOString() : null;
  // console.log(choiceOptions);

  const result = mapProjectType(choiceOptions, projectType);
  // console.log(result);
  // console.log(selectedProjectName,"selectedProjectName")
  // console.log(selectedProjectTaskName,"selectedProjectTaskName")
  // console.log(bookableResourceObjectOFUser?._msdyn_organizationalunit_value)

  const newEntryPayload = {
    hollis_projecttype: result,
    // Project Type
    // "msdyn_project@odata.bind": `msdyn_projects(${selectedProjectIdTable})`,
    // "msdyn_projectTask@odata.bind": `msdyn_projecttasks(${selectedProjectTaskIdTable})`,

    // "msdyn_project@odata.bind": `msdyn_projects(${selectedProjectIdNew})`,
    // "msdyn_projectTask@odata.bind": `msdyn_projecttasks(${selectedProjectTaskIdNew})`,
    "msdyn_project@odata.bind": `/msdyn_projects(${selectedProjectIdNew})`,
    "msdyn_projectTask@odata.bind": `/msdyn_projecttasks(${selectedProjectTaskIdNew})`,
    "hollis_bookableresourceorganisationalunit@odata.bind": `/msdyn_organizationalunits(${bookableResourceObjectOFUser?._msdyn_organizationalunit_value})`,
    msdyn_date: formattedDate,
    // Date formatted as ISO 8601
    msdyn_duration: parseInt(durationValue, 10) || 0,
    // Convert duration to integer
    msdyn_description: descriptionValue // Description
  };

  // Log the payload before posting
  // console.log("Payload to be sent:", newEntryPayload);
  // console.log(newEntryPayload);
  try {
    const response = await fetch(
    // `https://hollis-projectops-dev-01.api.crm4.dynamics.com/api/data/v9.2/msdyn_timeentries`,
    `${domain}/api/data/v9.2/msdyn_timeentries`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
        "OData-Version": "4.0",
        "OData-MaxVersion": "4.0",
        "MSCRM.SuppressDuplicateDetection": "false"
      },
      body: JSON.stringify(newEntryPayload)
    });

    // Office.context.ui.closeContainer();
    // console.log(response);

    if (!response.ok) {
      const errorText = await response.text(); // Capture response even if it's not JSON

      let error = JSON.parse(errorText);
      // console.log(error);
      insertError.style.color = "red";
      insertError.style.fontSize = "10px";
      insertError.textContent = bookableResourceObjectOFUser === undefined ? `"Sorry, unable to identify the user in Bookable Resources. Please contact your administrator for assistance."

` : `"The operation could not be completed due to missing or invalid data. Please review your input and try again."`;

      // Re-enable the button on error
      // const insertButton = document.getElementById("insertTimeEntry") as HTMLElement;
      // insertButton.style.pointerEvents = "auto";
      // insertButton.style.opacity = "1";

      throw new Error(`Error creating record: ${response.status} ${response.statusText} - ${errorText}`);
    } else {
      insertError.textContent = "Time entry inserted successfully. Please close the task pane using the cross icon at the top right corner.";
      insertError.style.color = "Green";
      insertError.style.marginBottom = "10px";

      // const insertButton = document.getElementById("insertTimeEntry") as HTMLElement;
      // insertButton.style.pointerEvents = "none";
      // insertButton.style.opacity = "0.5";
      // console.log(type)

      setTimeout(() => {
        insertError.textContent = '';
      }, 3000);
      if (type === 'saveAndClose') {
        setTimeout(() => {
          if (host === Office.HostType.Outlook) Office.context.ui.closeContainer();
        }, 3000);
      } else {
        // console.log(type)
        dateElement.value = '', searchInputProject.value = '', searchInputTask.value = '',
        // duration.value='',
        durationDropdown.value = '', description.value = '', projectType = "Client", client.classList.add("active", "toggle-btn");
        internal.classList.remove("active");
        await fetchProject(token);
      }
    }

    // Check if response has content before parsing JSON
  } catch (error) {
    // console.error("Error:", error);
  }
}